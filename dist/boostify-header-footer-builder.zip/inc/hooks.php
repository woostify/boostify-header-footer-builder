<?php

add_action( 'boostify_hf_seach_form', 'boostify_hf_search_form', 10 );

