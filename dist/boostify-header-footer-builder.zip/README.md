=== Boostify Header, Footer builder with Elementor ===
Contributors: woostify
Tags: elementor, header footer builder, header, footer, page builder, template builder, landing page builder, front-end editor
Requires at least: 4.4
Requires PHP: 5.4
Tested up to: 5.3
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Create Header and Footer for your site using Elementor Page Builder.