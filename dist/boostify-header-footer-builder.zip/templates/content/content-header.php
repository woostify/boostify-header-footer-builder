<header id="masthead" class="boostify-site-header">
	<?php the_content(); ?>
</header>
