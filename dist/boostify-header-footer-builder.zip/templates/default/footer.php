<?php
	do_action( 'boostify_hf_get_footer' );
	wp_footer();
?>
</div>
</body>
</html>
